# Pixel Run

Ein 2D-Jump-’n’-Run in Python und pygame. Vier Level mit steigendem
Schwierigkeitsgrad, Gegnern, Münzen und einem Bosskampf zum Abschluss.
Die gesamte Grafik wird zur Laufzeit im Code gezeichnet – das Spiel kommt
ohne einzige Bilddatei aus.

## Funktionen

- Vier Level: Easy, Medium, Hard und Bossarena
- Spielfigur mit Doppelsprung, Lauf- und Sprunganimation
- Zwei Gegnertypen: Pilzgegner und Stachelkugel, Besiegen durch Aufspringen
- Boss mit Lebensanzeige, Projektilen und Trefferanimation
- Punktesystem, Leben, Menü, Game-over- und Gewinnbildschirm
- Prozedurale Pixelgrafik: Figuren, Hintergrund, Wolken und Mond werden
  komplett mit `pygame.draw` erzeugt

## Screenshots

<!-- Bilder in docs/screenshots/ ablegen und hier einbinden -->
![Startmenü](docs/screenshots/01-menue.png)
![Level 3](docs/screenshots/03-level-3.png)
![Bosskampf](docs/screenshots/04-bossfight.png)

## Steuerung

| Taste | Aktion |
| --- | --- |
| ← → oder A D | laufen |
| Leertaste, ↑ oder W | springen (zweimal für den Doppelsprung) |
| Enter | Spiel starten oder neu starten |
| Esc | beenden |

## Technologien

| Bereich | Einsatz |
| --- | --- |
| Python 3.10+ | Programmiersprache |
| pygame 2.6 | Fenster, Eingabe, Zeichnen |
| unittest | automatisierte Tests |

## Installation

```bash
git clone https://github.com/BENUTZERNAME/pixel-run.git
cd pixel-run
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Verwendung

```bash
python main.py
```

## Tests

```bash
python -m unittest discover -s tests -v
```

14 Tests prüfen den Levelaufbau: Positionen der Münzen und Gegner, die
Plattformen und die Zielfahne. Sie laufen ohne Fenster und ohne pygame.

## Projektstruktur

```
pixel-run/
├── main.py         Einstiegspunkt: Fenster, Spielschleife
├── game.py         Spielzustand, Levelwechsel, HUD, Menüs
├── levels.py       Plattform-, Münz- und Gegnerlayouts
├── player.py       Spielfigur: Eingabe, Physik, Kollision
├── enemies.py      Gegnerlogik
├── boss.py         Boss und Projektile
├── sprites.py      alle Zeichenfunktionen der Pixelgrafik
├── constants.py    Konstanten: Größen, Physik, Farben, Punkte
└── tests/          Unit-Tests
```

## Bekannte behobene Fehler

- **Münzen in Level 3 waren nicht erreichbar.** Jede Plattform erhielt drei
  Münzen unabhängig von ihrer Breite. Auf den schmalen Plattformen des
  dritten Levels lag die letzte Münze dadurch neben der Plattform, auf der
  äußersten rechten sogar außerhalb des Bildschirms – das Level konnte nie
  vollständig abgeschlossen werden. Die Anzahl richtet sich jetzt nach der
  Plattformbreite, und die Münzen werden mittig verteilt.
- **Level 3 hatte keine Gegner.** Gegner wurden nur auf Plattformen ab 70
  Pixel Breite gesetzt; in Level 3 ist keine Plattform so breit. Die Grenze
  liegt nun bei 45 Pixeln, der Breite, die eine Figur zum Patrouillieren
  braucht.
- Level 3 wurde in der Anzeige als „???“ geführt und heißt jetzt „HARD“.

## Lizenz

MIT
