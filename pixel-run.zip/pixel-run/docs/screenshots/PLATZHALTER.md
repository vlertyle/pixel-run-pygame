Hier 3–5 Screenshots ablegen, z. B.:
  01-menue.png        Startmenü
  02-level-1.png      Level 1
  03-level-3.png      Level 3 (die schwierigen schmalen Plattformen)
  04-bossfight.png    Bosskampf
  05-game-over.png    Game-Over-Bildschirm
Danach die Bilder im README.md unter "Screenshots" verlinken und diese Datei löschen.
